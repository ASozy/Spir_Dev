#include <stdio.h>
#include <stdlib.h>

int Fact(int n)
{
	if( n == 0 ) return(1);   // 0! = 1;
	else return(n*Fact(n-1)); // n! = n*(n-1)!
}

int main(int argc, char *argv[])
{
	int n;
	
	// ввод числа
	printf("Number: ");
	scanf("%d", &n);
	
	printf("%d! = %d", n, Fact(n)); // вычисление факториала
	return 0;
}