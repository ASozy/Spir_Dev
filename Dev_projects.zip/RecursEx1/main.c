#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

//-------------------------------------------------------
int IsNumber(char *s)
{   
	printf("%s\n", s);  
	if( *s == '\0' ) return(1);  // дошли до конца строки и не встретили не цифр
	if( *s >= '0' && *s <= '9' ) // первый символ - цифра
		return(IsNumber(s+1));   // рекурсивный вызов IsNumber
	else
	 	return(0); // встретился символ - не цифра
}

int main(void)
{
	char s[256]; // анализируемая строка
	
	// ввод строки
	printf("String: ");
	scanf("%s", s);

	// рекурсия
	if( IsNumber(s) ) printf("Number");
	else printf("Not number");
	
	return 0;
}

