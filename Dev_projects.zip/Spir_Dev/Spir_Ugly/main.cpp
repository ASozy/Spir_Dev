#include <iostream>

class CTEST
{
	private:
		int i_private;
		
	public:
		CTEST(int i);
		int i_public;	
};

CTEST::CTEST(int i)
{
	i_public = i;
};

int main(int argc, char** argv)
{
	CTEST t(5);
	CTEST *pt = new CTEST(7);

	
	std::cout << t.i_public << "   " << pt->i_public;
	return 0;
}