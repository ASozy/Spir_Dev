#include <stdio.h>
#include <stdlib.h>
#include <math.h>

float Sin(float x)
{
	int i = 1; 
	double y = x, s = x;
	while( fabs(y/s) > 1.e-10 ) 
	{ 
		i += 2;
		y *= -(x*x)/(i*(i-1)); 
		s += y;
	}
	printf("i = %d  y = %lf\n", i, y);
	return(s); 
}

int main(void) 
{
	double x;
	float xd;
	int n; // номер слагаемого yn 
	printf("x (degrees) = ");
	scanf("%f", &xd); // xd - градусы
	x = xd*M_PI/180;  // x - радианы
	
	printf("sin(%f) = %lf\n", xd, sin(x));
	printf("Sin(%f) = %lf\n", xd, Sin(x));
	return 0;
}